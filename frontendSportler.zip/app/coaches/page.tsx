import CoachesLayout from "@/components/coaches/CoachesLayout"

export default function CoachesPage() {
  return <CoachesLayout city="default"/>
}

