"use client"

export default function SupplierAppTurfAdd() {
  return (
    <div className="h-full">
      <iframe src="/supplier/turf/add" className="w-full h-[calc(100vh-140px)] border-0" title="Add Turf" />
    </div>
  )
}
