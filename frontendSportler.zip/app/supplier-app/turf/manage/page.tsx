"use client"

export default function SupplierAppTurfManage() {
  return (
    <div className="h-full">
      <iframe src="/supplier/turf" className="w-full h-[calc(100vh-140px)] border-0" title="Turf Management" />
    </div>
  )
}
    