"use client"

export default function SupplierAppAcademyAdd() {
  return (
    <div className="h-full">
      <iframe src="/supplier/academy/add" className="w-full h-[calc(100vh-140px)] border-0" title="Add Academy" />
    </div>
  )
}
