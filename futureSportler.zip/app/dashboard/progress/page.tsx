"use client"

import SkillProgress from "@/components/dashboard/SkillProgress"

export default function ProgressPage() {
  return (
    <div className="p-6">
      <SkillProgress />
    </div>
  )
}
