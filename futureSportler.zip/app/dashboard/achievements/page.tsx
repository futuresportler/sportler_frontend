"use client"

import AchievementCards from "@/components/dashboard/AchievementCards"

export default function AchievementsPage() {
  return (
    <div className="p-6">
      <AchievementCards />
    </div>
  )
}
