"use client"

import Leaderboard from "@/components/dashboard/Leaderboard"

export default function LeaderboardPage() {
  return (
    <div className="p-6">
      <Leaderboard />
    </div>
  )
}
