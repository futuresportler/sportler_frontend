import { CourtsLayout } from "@/components/courts/CourtsLayout"

export default function CourtsPage() {
  return (
    <div className="w-full">
      <CourtsLayout />
    </div>
  )
}

