import { MultiRoleSignUpForm } from "@/components/auth/multi-role-sign-up-form"

export default function MultiRoleSignUp() {
  return (
    <div>
      <MultiRoleSignUpForm />
    </div>
  )
}
