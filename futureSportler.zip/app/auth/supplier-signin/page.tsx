"use client"
import { SupplierSignInForm } from "@/components/auth/supplier-sign-in-form"

export default function SupplierSignIn() {
  return (
    <div>
      <SupplierSignInForm />
    </div>
  )
}
