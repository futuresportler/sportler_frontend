import AcademiesLayout from "@/components/academies/AcademiesLayout"

export default function AcademiesPage() {
  return <AcademiesLayout />
}
